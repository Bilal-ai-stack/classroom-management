@echo off
start "" "%~dp0ClassroomOS.exe" %*

